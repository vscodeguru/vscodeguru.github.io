﻿$SiteURL = 'https://dvagov.sharepoint.com/sites/RPAITBF'
$SourceFile = '/Shared Documents/General/Group Emails.xlsx'
$folderName = "/Shared Documents/General/Pre-Production/ITBEAS_BF_STA101 Status of Allowance/Artifacts"
$DownloadPath = 'C:\Users\OITCOChintR\Downloads\SharePointDownload\'
$Filename = 'SOAConfigFile3.json'
 

try {
$devConn = Connect-PnPOnline -Url $SiteURL -UseWebLogin
$fileText = Get-PnPFile -Url $SourceFile -AsString -Connection $devConn

 Set-Content C:\Users\OITCOChintR\Downloads\SharePointDownload\Allowanc11e1.xlsx $fileText
<#
$devConn = Connect-PnPOnline -Url $SiteURL -UseWebLogin

$fileText = Get-PnPFile -Url $SourceFile -AsString -Connection $devConn
Write-Host $fileText
 
$folderItems = Get-PnPFolderItem -FolderSiteRelativeUrl $folderName -Connection $devConn
foreach($item in $folderItems)
{
    Write-Host $item.Name
}
#>
 
  Write-Host "done"
}
catch {
    Write-Host -f Red "Error:" $_.Exception.Message
}
#